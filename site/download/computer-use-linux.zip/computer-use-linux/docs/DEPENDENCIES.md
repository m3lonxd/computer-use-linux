# Bağımlılıklar

## Linux

Birincil ortam: KDE Plasma 6 (Wayland). Ölçüldüğü sistem: Debian 13,
KWin 6.3.6, xdg-desktop-portal-kde 6.3.5 (2026-10-16). X11 oturumunda
`python3-xlib` ile XTEST + EWMH kullanılır (izin istemez); Sway ve Hyprland'de
pencereler `swaymsg` / `hyprctl` ile, klavye wtype ile. Sway'de fare ek paket
istemez: Sway IPC (`seat cursor`) taşır ve tıklar, tekerlek wlroots sanal
fare protokolüyle gönderilir. Ekran görüntüsü wlroots'ta grim ile alınır.

| Yetenek | Ne kullanılır | Paket (Debian / Arch) | Yoksa |
|---|---|---|---|
| Tüm pencereler, öne getir/kapat, imleç konumu | KWin scripting (D-Bus) | KDE ile gelir | Yalnızca AT-SPI pencereleri |
| Fare + klavye | xdg-desktop-portal RemoteDesktop v2 + ScreenCast | `xdg-desktop-portal-kde`, `pipewire` | `key`/`type`/`click X Y` çalışmaz |
| Latin-1 dışı metin (ğ ş ı, emoji) | pano üzerinden yapıştırma | `wl-clipboard` | Bu karakterler yazılamaz |
| D-Bus erişimi | dbus-python + PyGObject | `python3-dbus python3-gi` / `python-dbus python-gobject` | Yukarıdakilerin hiçbiri |
| Öğe ağacı, isimle tıklama | AT-SPI | `gir1.2-atspi-2.0` / `at-spi2-core` | `tree`/`find`/`click REF` çalışmaz |
| Açık terminaller | Konsole D-Bus, tmux | `konsole`, `tmux` | Yalnızca ilgili tür listelenmez |
| Kendi terminal oturumları | tmux (yoksa PTY) | `tmux` | PTY'ye düşer |
| Ekran görüntüsü | spectacle / grim | `spectacle` veya `grim` | `screenshot` çalışmaz |
| Hızlı ekran görüntüsü (~0.2 sn) | fare/klavye servisinin ekran yayını (PipeWire) | `gstreamer1.0-pipewire` | Screenshot portalı / spectacle'a düşer (~0.5–1.5 sn) |
| Kırpma / küçültme | Pillow | `python3-pil` / `python-pillow` | Yalnızca tam boy görüntü |
| Görünür ajan imleci | python-xlib + XWayland | `python3-xlib` | İmleç gösterilmez (tıklama yine çalışır) |
| MCP adaptörü | `mcp` ≥ 2 | `pip install mcp` | CLI/HTTP yine çalışır |

## Neden wtype / ydotool değil

- **wtype**, `zwp_virtual_keyboard_v1` ister. KWin bunu sunmaz:
  `Compositor does not support the virtual keyboard protocol`.
- **ydotool / dotool**, `/dev/uinput`'a yazar; varsayılan izin `root:root 0600`.
  Root veya udev kuralı gerektirir.
- **RemoteDesktop portalı** root istemez. Kullanıcı bir kez onaylar
  ("Allow restoring on future sessions" işaretli). Verilen `restore_token`
  `~/.config/computer-use-linux/portal.json` dosyasına yazılır ve sonraki oturumlar
  diyalog açmadan başlar. İzni geri almak için bu dosyayı silmek yeterli.

## Erişilebilirlik ağacı

KDE varsayılan olarak `org.a11y.Status.IsEnabled=false` ile gelir. Bu durumda
Qt uygulamaları (Konsole, Dolphin...) ağaç yayınlamaz. `computer-use-linux setup` bu
ayarı açar; o andan sonra başlatılan uygulamalar ağaç yayınlar. Firefox
tabanlı tarayıcılar ağacı kendiliğinden yayınlar. Electron/Chromium
uygulamaları (Discord, VS Code, Slack, Chrome) yalnızca
`--force-renderer-accessibility` ile başlatılırsa yayınlar; çalışırken
açılamaz (`ScreenReaderEnabled` ve `ACCESSIBILITY_ENABLED` canlı etki etmez).
`computer-use-linux launch <program>` bayrağı ve Qt/GTK erişilebilirlik ortamını
ekleyip uygulamayı başlatır, açılan pencerenin ref'ini döndürür.

## Windows

| Yetenek | Ne kullanılır | Kurulum | Yoksa |
|---|---|---|---|
| Pencereler, fare, klavye, ekran görüntüsü | Win32 (ctypes, stdlib) | — | — |
| Öğe ağacı, isimle tıklama | UI Automation | `comtypes` (pip ile otomatik) | `tree`/`find`/`click REF` çalışmaz |
| Açık konsollar | AttachConsole yardımcı süreci | python.exe (paketlenmiş exe'de yok) | `terms` çalışmaz |
| Kırpma / küçültme, MCP | Pillow, mcp | `pip install .[all]` | Yalnızca tam boy görüntü / CLI-HTTP |
| Görünür ajan imleci | katmanlı pencere (ctypes, stdlib); daemon belirteçli 127.0.0.1 TCP | — | — |

Yönetici olarak çalışan pencerelere UIPI nedeniyle yalnızca yönetici olarak
başlatılmış Computer Use Linux giriş gönderebilir.

## macOS (önizleme)

| Yetenek | Ne kullanılır | İzin | Yoksa |
|---|---|---|---|
| Fare, klavye | Quartz CGEvent (ctypes) | Erişilebilirlik | `click`/`key`/`type` çalışmaz |
| Pencereler | CGWindowList + AX | Ekran Kaydı (başlıklar için), Erişilebilirlik (eylemler) | Başlıklar boş gelir |
| Öğe ağacı | Accessibility (AXUIElement) | Erişilebilirlik | `tree`/`find` çalışmaz |
| Ekran görüntüsü | `screencapture` | Ekran Kaydı | `screenshot` çalışmaz |
| Açık terminaller | Terminal.app / iTerm2 (AppleScript), tmux | Otomasyon (ilk kullanımda sorulur) | Yalnızca tmux |
| Görünür ajan imleci | NSWindow (ctypes objc, pyobjc gerekmez) | — | İmleç gösterilmez |

`computer-use-linux setup` izin istemlerini açar. İzinler Sistem Ayarları → Gizlilik ve
Güvenlik altından geri alınır.

## GNOME (Mutter) — gerçek GNOME Shell 48.7'de doğrulandı (başsız, Docker)

- Pencere listesi: GNOME'da pencere-yönetici kanalı yok; AT-SPI penceresi olan uygulamalar listelenir.
- Fare/klavye: varsayılan RemoteDesktop portalıdır (ilk kullanımda GNOME izin sorar).
  Başsız/uzaktan yönetilen makinelerde `CUL_INPUT_BACKEND=mutter` portalsız,
  izinsiz `org.gnome.Mutter.RemoteDesktop` yolunu seçer (kullanıcı onayı atlanır; bilerek kullanın).
- ASCII dışı (ü, ğ, é...) metin Mutter'da klavye düzenine bağlı olduğundan panodan yapıştırılır: `wl-clipboard`.
- Ekran görüntüsü: `gnome-screenshot`, yoksa Mutter yolunda `gstreamer1.0-pipewire` + `gstreamer1.0-tools`,
  portal yolunda xdg-desktop-portal Screenshot.
- Test: `tests/gnome_sandbox.sh python3 tests/test_gnome_sandbox.py` (gnome-shell, xdg-desktop-portal-gnome,
  python3-dbusmock gerekir; yoksa atlanır).
